import React from "react";

const NotFound = () => {
  return <div className="p-6 mt-5 shadow rounded bg-white">NotFound</div>;
};

export default NotFound;
